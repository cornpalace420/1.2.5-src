package org.lwjgl;

public interface PointerWrapper {
	long getPointer();
}