package org.lwjgl.util.vector;

public interface ReadableVector4f extends ReadableVector3f {

	float getW();

}