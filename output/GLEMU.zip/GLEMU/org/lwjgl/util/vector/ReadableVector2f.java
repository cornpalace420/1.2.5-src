package org.lwjgl.util.vector;

public interface ReadableVector2f extends ReadableVector {
	float getX();
	float getY();
}