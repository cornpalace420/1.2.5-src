package org.lwjgl.util.vector;

public interface WritableVector2f {

	void setX(float x);

	void setY(float y);
	
	void set(float x, float y);

}