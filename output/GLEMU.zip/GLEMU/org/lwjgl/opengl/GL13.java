package org.lwjgl.opengl;

public class GL13 extends GL12 {

}
